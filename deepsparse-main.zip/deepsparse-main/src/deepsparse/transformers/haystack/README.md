# Information Retrieval with Haystack #
For more information about setup, usage, and examples see [integrations/haystack/README.md](https://github.com/neuralmagic/deepsparse/tree/main/integrations/haystack/README.md)
